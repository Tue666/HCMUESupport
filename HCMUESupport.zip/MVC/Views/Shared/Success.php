<div class="content">
    <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%;width:100%;">
        <i class="fas fa-check-circle fa-10x text-success"></i>
        <label>Đặt hàng thành công. </label>
        <label>Nhấn 'Lịch sử' để xem lịch sử giao dịch.</label>
        <div style="display:flex">
            <button class="btn btn-primary m-1" onclick="window.location.href='<?php echo BASE_URL; ?>'">Trang chủ</button>
            <button class="btn btn-warning m-1" onclick="window.location.href='<?php echo BASE_URL . 'Home/History'; ?>'">Lịch sử</button>
        </div>
    </div>
</div>