<?php
class ErrorPage{
    public function Index(){
        echo '404';
    }
}
?>