<div class="content">
    <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%;width:100%;">
        <i class="fas fa-exclamation-circle fa-10x text-danger"></i>
        <label>Đặt hàng không thành công. </label>
        <label>Đã có lỗi xảy ra, liên hệ BCH để thêm thông tin và hỗ trợ. </label>
        <button class="btn btn-primary" onclick="window.location.href='<?php echo BASE_URL; ?>'">Trang chủ</button>
    </div>
</div>