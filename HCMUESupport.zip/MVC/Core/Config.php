<?php  
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
	define('DB_HOST', 'localhost');
	define('DB_SERVERNAME', 'database');

	// define('DB_USERNAME', 'id16381694_admin');
	// define('DB_PASSWORD', '1r!72Be0c&Gc7{Vy');
	// define('DB_HOST', 'localhost');
	// define('DB_SERVERNAME', 'id16381694_dotshop');

// User define
	define('BASE_URL','http://localhost/HCMUESupport/');
	define('CSS_URL','http://localhost/HCMUESupport/Public/css');
	define('IMAGE_URL','http://localhost/HCMUESupport/Public/images');
	define('JS_URL','http://localhost/HCMUESupport/Public/js');

// Admin define
	define('ADMIN_BASE_URL','http://localhost/HCMUESupport/Admin/');
	define('ADMIN_CSS_URL','http://localhost/HCMUESupport/Public/admin/css');
	define('ADMIN_IMAGE_URL','http://localhost/HCMUESupport/Public/admin/images');
	define('ADMIN_JS_URL','http://localhost/HCMUESupport/Public/admin/js');

?>