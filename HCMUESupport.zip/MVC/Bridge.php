<?php
    require_once('./MVC/Core/App.php');
    require_once('./MVC/Core/ViewModel.php');
    require_once('./MVC/Core/Config.php');
    require_once('./MVC/Core/Database.php');
?>