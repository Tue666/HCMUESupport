<?php
    session_start();
    require_once('./MVC/Bridge.php');
    $init = new App();
?>